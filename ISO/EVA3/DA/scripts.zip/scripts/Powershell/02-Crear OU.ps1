.\00-variables.ps1

###############################################################


# Creamos as Unidades Organizativas do nivel superior
# Poderíamos crealas empregando o mesmo comando que no bat
#    dsadd ou "ou=Usuarios, dc=$env:nomeDominio, dc=$env:extDominio"
# Pero preferimos facelo empregando un xeito propio de powershell


NEW-ADOrganizationalUnit -name Usuarios -path "dc=$env:nomeDominio,dc=$env:extDominio" -ProtectedFromAccidentalDeletion $false
NEW-ADOrganizationalUnit -name Alumnos -path "ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio"  -ProtectedFromAccidentalDeletion $false
NEW-ADOrganizationalUnit -name Profesores -path "ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio" -ProtectedFromAccidentalDeletion $false
NEW-ADOrganizationalUnit -name Administraci�n -path "ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio" -ProtectedFromAccidentalDeletion $false

# No bucle recorremos o contido de cursos.txt
foreach ($i in get-content grupos\cursos.txt) {
	# Creamos as Unidades Organizativas dos Cursos
	NEW-ADOrganizationalUnit -name $i -path "ou=Alumnos,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio" -ProtectedFromAccidentalDeletion $false 
	foreach ($j in get-content grupos\grupos$i.txt) {
		NEW-ADOrganizationalUnit -name $j -path "ou=$i,ou=Alumnos,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio" -ProtectedFromAccidentalDeletion $false
	}
 }
 