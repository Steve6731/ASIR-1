.\00-variables.ps1

###############################################################
# Eliminando $env:unidade\Datos
#
# Para evitar mensaxes de erro 
# Se existe $env:unidade\Datos
#	entonces
#		convirto a administrador en propietario da carpeta/subcarpeta e arquivos
#		Engado a ACE Administrador:CT en todos os arquivos/carpetas
#		Borro $env:unidade\Datos
#   senón Amoso unha mensaxe de erro
###############################################################

#Se  existe
if ((Test-path -path $env:unidade\Datos)){
	echo "Borrando a carpeta Datos..."
	# Tomamos posesión
	# Hai unha función powershell para isto pero teríamos que descargala
	# https://gallery.technet.microsoft.com/scriptcenter/Set-Owner-ff4db177
	takeown /r /f $env:unidade\Datos /d s

	# Engadimos na ACL de todos os arquivos/carpetas
	# a ACE Administradores Control Total

	# Creamos a ACE que queremos engadir
	$rule = New-Object System.Security.AccessControl.FileSystemAccessRule ("Administradores","FullControl","Allow")

	# Recorremos as carpetas/ficheiros da xerarquía 
	# -Force para que recorra tamén os ocultos
	$filesarray = Get-ChildItem $env:unidade\Datos -Recurse  -Force
	ForEach($path in $filesarray) {
		$acl = Get-Acl $path.fullname
		#Aplicamos regra
		$acl.SetAccessRule($rule) > $null
		$acl |Set-Acl -Path $path.fullname
	}
	# Aplicamos a regra á carpeta Datos
	$acl = Get-Acl $env:unidade\Datos
	$acl.SetAccessRule($rule) > $null
	$acl |Set-Acl -Path $env:unidade\Datos

	#Eliminamos a carpeta Datos
	remove-item $env:unidade\Datos -recurse -Force
	echo "Carpeta Datos borrada"
} else  {echo "A carpeta Datos non existe"}
###############################################################
# Eliminamos a Unidade Organizativa Usuarios
# O eliminala, tamén se eliminan todos os grupos e usuarios
# Se existe
# 	entonces borro a OU
#	senón amoso unha mensaxe de erro
###############################################################
$oucheck= [adsi]::Exists("LDAP://ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio")
if($oucheck -eq "true") {
	echo "Eliminando OU Usuarios..."
	Get-ADOrganizationalUnit -Identity "ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio" |
                                  Set-ADObject -ProtectedFromAccidentalDeletion:$false -PassThru |
                                  Remove-ADOrganizationalUnit -Confirm:$false -Recursive
	echo "OU Usuarios eliminada"
	} else {echo "Non existe a OU Usuarios"}

