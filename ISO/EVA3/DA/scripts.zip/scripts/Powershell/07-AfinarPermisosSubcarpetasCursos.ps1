.\00-variables.ps1

#No bucle recorremos o contido de cursos.txt
foreach ($i in get-content grupos\cursos.txt) {
	#Asignamos os grupos dos usuarios ás carpetas dos cursos
	$perm= "G-$i" + ":RX"
	icacls $env:unidade\Datos\Cursos\$i /grant  $perm
	foreach ($j in get-content grupos\grupos$i.txt) {
		$perm2= "G-$j" + ":RX"
		icacls $env:unidade\Datos\Cursos\$i\$j /grant $perm2
	}
}
