.\00-variables.ps1

# ------------------------------
# Axustamos os permisos de Datos
# ------------------------------

# Rompemos a herdanza
icacls  $env:unidade\Datos  /inheritance:d
# Quitamos as ACE's Creator Owner e Usuarios
icacls  $env:unidade\Datos  /remove "creator owner"
icacls  $env:unidade\Datos  /remove "usuarios"
# Engadimos a ACE G-Xilgaro con permiso Lectura e Execuci�n
# Aplicado a Esta carpeta, Subcarpetas e Arquivos
icacls  $env:unidade\Datos /grant "G-Xilgaro:(OI)(CI)RX"

# ------------------------------
# Axustamos os permisos de Perf�s
# ------------------------------

# Engadimos o permiso Escritura � ACE G-Xilgaro
icacls  $env:unidade\Datos\Usuarios\Perf�s /grant "G-Xilgaro:(OI)(CI)W"

# ------------------------------
# Axustamos os permisos de Redirecci�ns
# ------------------------------

# Engadimos a ACE "Creator Owner" con permiso Control Total
# Aplicado a Subcarpetas e Arquivos
icacls  $env:unidade\Datos\Usuarios\Redirecci�ns /grant "Creator Owner:(OI)(CI)F"
# Engadimos o Permiso Avanzado Crear Carpetas � ACE G-Xilgaro
icacls  $env:unidade\Datos\Usuarios\Redirecci�ns /grant "G-Xilgaro:(OI)(CI)(AD)"

# ------------------------------
# Axustamos os permisos de Alumnos
# ------------------------------

# Engadimos a ACE "Creator Owner" con permiso Control Total
# Aplicado a Subcarpetas e Arquivos
icacls  $env:unidade\Datos\Usuarios\Alumnos /grant "Creator Owner:(OI)(CI)F"
# Engadimos o Permiso Avanzado Crear Carpetas � ACE G-Xilgaro
icacls  $env:unidade\Datos\Usuarios\Alumnos /grant "G-Xilgaro:(OI)(CI)(AD)"

# ------------------------------
# Axustamos os permisos de Profesores
# ------------------------------
# Rompemos a herdanza
icacls  $env:unidade\Datos\Usuarios\Profesores  /inheritance:d
# Engadimos a ACE "Creator Owner" con permiso Control Total
# Aplicado a Subcarpetas e Arquivos
icacls  $env:unidade\Datos\Usuarios\Profesores /grant "Creator Owner:(OI)(CI)F"
# Eliminamos a G-Xilgaro
icacls  $env:unidade\Datos\Usuarios\Profesores /remove "G-Xilgaro"
# Engadimos o Permiso Avanzado Crear Carpetas � ACE G-Xilgaro
icacls  $env:unidade\Datos\Usuarios\Profesores /grant "G-Profesores:(OI)(CI)F"

#------------------------------
# Axustamos os permisos de Cursos
# ------------------------------
# Rompemos a herdanza
icacls  $env:unidade\Datos\Cursos  /inheritance:d
icacls  $env:unidade\Datos\Cursos  /remove "G-Xilgaro"
icacls  $env:unidade\Datos\Cursos  /grant "G-Profesores:(OI)(CI)RXW"
# Aplicado a Subcarpetas e Arquivos
icacls  $env:unidade\Datos\Cursos /grant "Creator Owner:(OI)(CI)F"
# Concedemos a G-alumnos permiso de lectura s� nesta carpeta
# Para acceder a cada un dos cursos ter� que ser membro do curso
icacls  $env:unidade\Datos\Cursos /grant "G-alumnos:RX"

# ------------------------------
# Axustamos os permisos de Administraci�n
# ------------------------------
# Rompemos a herdanza
icacls  $env:unidade\Datos\Administraci�n  /inheritance:d
# Quitamos a ACE's G-Xilgaro de Administraci�n
icacls  $env:unidade\Datos\Administraci�n  /remove "G-Xilgaro"
icacls  $env:unidade\Datos\Administraci�n /grant "G-Administraci�n:(OI)(CI)F"

# ------------------------------
# Axustamos os permisos de Com�n
# ------------------------------
# Engadimos a ACE "Creator Owner" con permiso Control Total
# Aplicado a Subcarpetas e Arquivos
icacls  $env:unidade\Datos\Com�n /grant "Creator Owner:(OI)(CI)F"

# ------------------------------
# Axustamos os permisos de Com�nProfes
# ------------------------------
# Rompemos a herdanza
icacls  $env:unidade\Datos\Com�n\Com�nProfes  /inheritance:d
# Quitamos a ACE G-Xilgaro
icacls  $env:unidade\Datos\Com�n\Com�nProfes  /remove "G-Xilgaro"
icacls  $env:unidade\Datos\Com�n\Com�nProfes /grant "G-Profesores:(OI)(CI)RXW"

# ------------------------------
# Axustamos os permisos de Com�nAlumnos
# ------------------------------
# Quitamos a ACE G-Xilgaro
icacls  $env:unidade\Datos\Com�n\Com�nAlumn /remove "G-Xilgaro"
icacls  $env:unidade\Datos\Com�n\Com�nAlumn /grant "G-Profesores:(OI)(CI)RX"
icacls  $env:unidade\Datos\Com�n\Com�nAlumn /grant "G-Alumnos:(OI)(CI)RXW"




 
 #https://4sysops.com/archives/create-a-new-folder-and-set-permissions-with-powershell/