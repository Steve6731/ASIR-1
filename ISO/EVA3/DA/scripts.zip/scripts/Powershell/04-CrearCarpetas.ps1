.\00-variables.ps1

# Esta � unha forma de crear carpetas en powershell
New-Item -Path $env:unidade\Datos  -ItemType directory | out-null
 
# Pero tam�n podemos empregar o alias md
# Rediriximos a sa�da est�ndar a out-null para 
# que o comando non amose nada por pantalla
md $env:unidade\Datos\Usuarios | out-null
md $env:unidade\Datos\Usuarios\Perf�s | out-null
md $env:unidade\Datos\Usuarios\Redirecci�ns | out-null
md $env:unidade\Datos\Usuarios\Alumnos | out-null
md $env:unidade\Datos\Usuarios\Profesores | out-null

# Creamos o resto de carpetas

md $env:unidade\Datos\Cursos | out-null
md $env:unidade\Datos\Administraci�n | out-null
md $env:unidade\Datos\Com�n | out-null
md $env:unidade\Datos\Com�n\Com�nProfes | out-null
md $env:unidade\Datos\Com�n\Com�nAlumn | out-null
 
 
 
 
 
 
 #https://4sysops.com/archives/create-a-new-folder-and-set-permissions-with-powershell/