net share Perf�s$ /delete
net share Redirecci�ns$ /delete
net share Administraci�n /delete
net share Alumnos /delete
net share Com�n /delete
net share Cursos /delete
net share Profesores /delete