.\00-variables.ps1


# No bucle recorremos o contido de cursos.txt
foreach ($i in get-content grupos\cursos.txt) {
	# Creamos as Carpetas dos Cursos
	md $env:unidade\Datos\Cursos\$i | out-null
	foreach ($j in get-content grupos\grupos$i.txt) {
		# Creamos as Carpetas dos  grupos dentro dos Cursos
		md $env:unidade\Datos\Cursos\$i\$j | out-null
		}
 }
 
 