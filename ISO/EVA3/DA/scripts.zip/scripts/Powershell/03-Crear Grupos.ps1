.\00-variables.ps1

###############################################################


# Creamos as Unidades Organizativas do nivel superior
# Poderíamos crealas empregando o mesmo comando que no bat
#    dsadd group ...
# Pero preferimos facelo empregando un xeito propio de powershell

#Creamos o grupo G-Xilgaro

# Primeiro Creamos o grupo G-Xilgaro na correspondente OU
NEW-ADGroup -name G-Xilgaro -path "ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio" -GroupScope Global -GroupCategory Security
# Engadimos o grupo a Usuaros del Dominio
Add-ADGroupMember -Identity "cn=Usuarios del dominio, cn=Users, dc=$env:nomeDominio,dc=$env:extDominio" -Members  "cn=G-Xilgaro,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio"

# Creamos G-Alumnos, G-Profesores e engadimolos a G-Xilgaro
NEW-ADGroup -name G-Alumnos -path "ou=Alumnos,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio" -GroupScope Global -GroupCategory Security
Add-ADGroupMember -Identity "cn=G-Xilgaro, ou=Usuarios, dc=$env:nomeDominio,dc=$env:extDominio" -Members  "cn=G-Alumnos,ou=Alumnos,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio"
NEW-ADGroup -name G-Profesores -path "ou=Profesores,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio" -GroupScope Global -GroupCategory Security
Add-ADGroupMember -Identity "cn=G-Xilgaro, ou=Usuarios, dc=$env:nomeDominio,dc=$env:extDominio" `
-Members  "cn=G-Profesores,ou=Profesores,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio"
NEW-ADGroup -name G-Administraci�n -path "ou=Administraci�n,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio" -GroupScope Global -GroupCategory Security
Add-ADGroupMember -Identity "cn=G-Xilgaro, ou=Usuarios, dc=$env:nomeDominio,dc=$env:extDominio" `
-Members  "cn=G-Administraci�n,ou=Administraci�n,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio"


# No bucle recorremos o contido de cursos.txt
foreach ($i in get-content grupos\cursos.txt) {
	# Creamos os Grupos dos Cursos
	NEW-ADGroup -name G-$i -path "ou=$i,ou=Alumnos,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio" -GroupScope Global -GroupCategory Security
	 Add-ADGroupMember -Identity "cn=G-Alumnos, ou=Alumnos, ou=Usuarios, dc=$env:nomeDominio,dc=$env:extDominio" `
	 -Members  "cn=G-$i,ou=$i,ou=Alumnos,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio"
	foreach ($j in get-content grupos\grupos$i.txt) {
		NEW-ADGroup -name G-$j -path "ou=$j,ou=$i,ou=Alumnos,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio" -GroupScope Global -GroupCategory Security
		Add-ADGroupMember -Identity "cn=G-$i, ou=$i, ou=Alumnos, ou=Usuarios, dc=$env:nomeDominio,dc=$env:extDominio" `
		-Members  "cn=G-$j,ou=$j,ou=$i,ou=Alumnos,ou=Usuarios,dc=$env:nomeDominio,dc=$env:extDominio"
		
	}  
 }
  