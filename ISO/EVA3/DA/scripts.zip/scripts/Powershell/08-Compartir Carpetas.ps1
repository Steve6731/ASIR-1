.\00-variables.ps1

# O seguinte comando funcionar�a dende Powershell
# net share Perf�s$=%unidade%\Datos\Usuarios\Perf�s /Grant:Todos,Full
# Pero queremos compartilas dun xeito m�is propio de powershell

# REM Compartimos as carpetas para os Perf�s e as Redirecci�ns
echo "Compartida Perf�s de xeito oculto"
New-SMBShare �Name "Perf�s$" �Path  $env:unidade\Datos\Usuarios\Perf�s �FullAccess Todos | out-null
echo "Compartida Redirecci�ns de xeito oculto"
New-SMBShare �Name "Redirecci�ns$" �Path  $env:unidade\Datos\Usuarios\Redirecci�ns �FullAccess Todos | out-null

# Compartimos o resto de carpetas do Dominio
echo "Compartida Alumnos"
New-SMBShare �Name "Alumnos" �Path  $env:unidade\Datos\Usuarios\Alumnos �FullAccess Todos | out-null
echo "Compartida Profesores"
New-SMBShare �Name "Profesores" �Path  $env:unidade\Datos\Usuarios\Profesores �FullAccess Todos | out-null
echo "Compartida Cursos"
New-SMBShare �Name "Cursos" �Path  $env:unidade\Datos\Cursos �FullAccess Todos | out-null
echo "Compartida Administraci�n"
New-SMBShare �Name "Administraci�n" �Path  $env:unidade\Datos\Administraci�n �FullAccess Todos | out-null
echo "Compartida Com�n"
New-SMBShare �Name "Com�n" �Path  $env:unidade\Datos\Com�n �FullAccess Todos | out-null

 