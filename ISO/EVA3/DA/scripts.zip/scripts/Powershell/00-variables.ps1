# Información do Dominio
$env:nomeDominio="xilgaro"
$env:extDominio="local"

#Directorio raíz da unidade datos
$env:unidade="D:"
