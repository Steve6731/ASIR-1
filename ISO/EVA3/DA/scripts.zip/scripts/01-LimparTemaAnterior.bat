@echo off
REM Informaci�n do Dominio
set nomeDominio=xilgaro
set extDominio=local
REM Directorio ra�< da unidade Usuarios
set unidade=D:
REM Cargamos a p�xina de c�digos de idioma correcto para que non de problemas coas tildes
mode con cp select=1250 > nul

rem -----------------------------
rem Descompartimos as carpetas
rem -----------------------------
net share Perf�s$ /delete
net share Redirecci�ns$ /delete

rem -----------------------------
rem Eliminamos a carpeta Usuarios
rem -----------------------------
rem Tomamos posesi�n
takeown /r /f %unidade%\Usuarios /d s
rem Engadimos na ACL de todos os arquivos/carpetas
rem a ACE Administradores Control Total
icacls %unidade%\Usuarios /grant administradores:F /T
rem Borramos a carpeta sen que pida confirmaci�n
rd /s /q %unidade%\Usuarios

rem -----------------------------
rem Eliminamos a OU Usuarios
rem -----------------------------
dsrm  "ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%" -subtree -noprompt