@echo off
call 00-variables.bat

rem Creamos as Unidades Organizativas do nivel superior

dsadd ou "ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%"
dsadd ou "ou=Alumnos,ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%"
dsadd ou "ou=Profesores,ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%"
dsadd ou "ou=Administraci�n,ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%"


rem No bucle recorremos o contido de cursos.txt
for /f %%i in ('type grupos\cursos.txt') do (
	rem Creamos as Unidades Organizativas dos Cursos
	dsadd ou "ou=%%i,ou=Alumnos,ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%"
	for /f %%j in ('type grupos\grupos%%i.txt') do (
		rem Creamos as Unidades Organizativas dos Grupos dentro dos Cursos
		dsadd ou "ou=%%j,ou=%%i,ou=Alumnos,ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%"
		rem echo %%j 
		
	)
)
