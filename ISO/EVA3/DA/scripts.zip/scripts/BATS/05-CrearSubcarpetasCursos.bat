@echo off
call 00-variables.bat


for /f %%i in ('type grupos\cursos.txt') do (
	rem Creamos as Carpetas dos Cursos
	md %unidade%\Datos\Cursos\%%i
	for /f %%j in ('type grupos\grupos%%i.txt') do (
		rem Creamos as Carpetas dos Grupos dentro dos Cursos
		md %unidade%\Datos\Cursos\%%i\%%j
	)
)
