@echo off
call 00-variables.bat
REM ------------------------------
REM Axustamos os permisos de Datos
REM ------------------------------

REM Rompemos a herdanza
icacls  %unidade%\Datos  /inheritance:d
REM Quitamos as ACE's Creator Owner e Usuarios
icacls  %unidade%\Datos  /remove "creator owner"
icacls  %unidade%\Datos  /remove "usuarios"
REM Engadimos a ACE G-Xilgaro con permiso Lectura e Execuci�n
REM Aplicado a Esta carpeta, Subcarpetas e Arquivos
icacls  %unidade%\Datos /grant G-Xilgaro:(OI)(CI)RX

REM ------------------------------
REM Axustamos os permisos de Perf�s
REM ------------------------------

REM Engadimos o permiso Escritura � ACE G-Xilgaro
icacls  %unidade%\Datos\Usuarios\Perf�s /grant G-Xilgaro:(OI)(CI)W

REM ------------------------------
REM Axustamos os permisos de Redirecci�ns
REM ------------------------------

REM Engadimos a ACE "Creator Owner" con permiso Control Total
REM Aplicado a Subcarpetas e Arquivos
icacls  %unidade%\Datos\Usuarios\Redirecci�ns /grant "Creator Owner":(OI)(CI)F
REM Engadimos o Permiso Avanzado Crear Carpetas � ACE G-Xilgaro
icacls  %unidade%\Datos\Usuarios\Redirecci�ns /grant G-Xilgaro:(OI)(CI)(AD)

REM ------------------------------
REM Axustamos os permisos de Alumnos
REM ------------------------------

REM Engadimos a ACE "Creator Owner" con permiso Control Total
REM Aplicado a Subcarpetas e Arquivos
icacls  %unidade%\Datos\Usuarios\Alumnos /grant "Creator Owner":(OI)(CI)F
REM Engadimos o Permiso Avanzado Crear Carpetas � ACE G-Xilgaro
icacls  %unidade%\Datos\Usuarios\Alumnos /grant G-Xilgaro:(OI)(CI)(AD)

REM ------------------------------
REM Axustamos os permisos de Profesores
REM ------------------------------

REM Rompemos a herdanza
icacls  %unidade%\Datos\Usuarios\Profesores  /inheritance:d
REM Engadimos a ACE "Creator Owner" con permiso Control Total
REM Aplicado a Subcarpetas e Arquivos
icacls  %unidade%\Datos\Usuarios\Profesores /grant "Creator Owner":(OI)(CI)F
REM Quitamos a ACE de G-Xilgaro
icacls  %unidade%\Datos\Usuarios\Profesores  /remove "G-Xilgaro"
REM Engadimos a ACE G-Profesores con permiso Control Total
icacls  %unidade%\Datos\Usuarios\Profesores /grant G-Profesores:(OI)(CI)F

REM ------------------------------
REM Axustamos os permisos de Cursos
REM ------------------------------
REM Rompemos a herdanza
icacls  %unidade%\Datos\Cursos  /inheritance:d
icacls  %unidade%\Datos\Cursos  /remove "G-Xilgaro"
icacls  %unidade%\Datos\Cursos  /grant "G-Profesores":(OI)(CI)RXW
REM Aplicado a Subcarpetas e Arquivos
icacls  %unidade%\Datos\Cursos /grant "Creator Owner":(OI)(CI)F
REM Concedemos a G-alumnos permiso de lectura s� nesta carpeta
REM Para acceder a cada un dos cursos ter� que ser membro do curso
icacls  %unidade%\Datos\Cursos /grant G-alumnos:RX

REM ------------------------------
REM Axustamos os permisos de Administraci�n
REM ------------------------------
REM Rompemos a herdanza
icacls  %unidade%\Datos\Administraci�n  /inheritance:d
REM Quitamos a ACE's G-Xilgaro de Administraci�n
icacls  %unidade%\Datos\Administraci�n  /remove "G-Xilgaro"
REM Concedemos o grupo G-Administraci�n Control Total
icacls  %unidade%\Datos\Administraci�n /grant "G-Administraci�n":(OI)(CI)F  

REM ------------------------------
REM Axustamos os permisos de Com�n
REM ------------------------------
REM Engadimos a ACE "Creator Owner" con permiso Control Total
REM Aplicado a Subcarpetas e Arquivos
icacls  %unidade%\Datos\Com�n /grant "Creator Owner":(OI)(CI)F

REM ------------------------------
REM Axustamos os permisos de Com�nProfes
REM ------------------------------
REM Rompemos a herdanza
icacls  %unidade%\Datos\Com�n\Com�nProfes  /inheritance:d
REM Quitamos a ACE G-Xilgaro
icacls  %unidade%\Datos\Com�n\Com�nProfes  /remove "G-Xilgaro"
icacls  %unidade%\Datos\Com�n\Com�nProfes /grant "G-Profesores":(OI)(CI)RXW

REM ------------------------------
REM Axustamos os permisos de Com�nAlumnos
REM ------------------------------
REM Quitamos a ACE G-Xilgaro
icacls  %unidade%\Datos\Com�n\Com�nAlumn /remove "G-Xilgaro"
icacls  %unidade%\Datos\Com�n\Com�nAlumn /grant "G-Profesores":(OI)(CI)RX
icacls  %unidade%\Datos\Com�n\Com�nAlumn /grant "G-Alumnos":(OI)(CI)RXW



