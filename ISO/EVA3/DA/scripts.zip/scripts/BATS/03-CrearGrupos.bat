@echo off
call 00-variables.bat

REM Creamos os grupos principais
REM dsadd group "Distinguished Name do grupo"
	REM -scope g -> Grupo Global
	REM -secgrp yes -> Grupo Seguridade
	REM -memberof -> Grupos os que pertence este grupo
dsadd group "cn=G-Xilgaro, ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%" -scope g -secgrp yes -memberof "cn=Usuarios del dominio, cn=Users, dc=%nomeDominio%, dc=%extDominio%"
dsadd group "cn=G-Alumnos, ou=Alumnos, ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%" -scope g -secgrp yes -memberof "cn=G-Xilgaro, ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%"
dsadd group "cn=G-Profesores, ou=Profesores, ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%" -scope g -secgrp yes -memberof "cn=G-Xilgaro, ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%"
dsadd group "cn=G-Administraci�n, ou=Administraci�n, ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%" ^
-scope g -secgrp yes -memberof "cn=G-Xilgaro, ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%"



rem No bucle recorremos o contido de cursos.txt
for /f %%i in ('type grupos\cursos.txt') do (
	rem Creamos os Grupos correspondente �s cursos nas s�as Unidades Organizativas
	dsadd group "cn=G-%%i,ou=%%i, ou=Alumnos, ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%" -scope g -secgrp yes ^
	-memberof "cn=G-Alumnos, ou=Alumnos, ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%"
	for /f %%j in ('type grupos\grupos%%i.txt') do (
		REM Creamos os Grupos correspondente �s m�dulos nas s�as Unidades Organizativas
		dsadd group "cn=G-%%j,ou=%%j,ou=%%i, ou=Alumnos, ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%" -scope g -secgrp yes ^
		-memberof "cn=G-%%i,ou=%%i,ou=Alumnos, ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%"
	 )
)

