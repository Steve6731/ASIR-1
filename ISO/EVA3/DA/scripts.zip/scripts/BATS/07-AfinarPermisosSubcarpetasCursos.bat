@echo off
call 00-variables.bat

for /f %%i in ('type grupos\cursos.txt') do (
	rem Asignamos os grupos de usuarios as carpetas dos cursos
	icacls  %unidade%\Datos\Cursos\%%i  /grant "G-%%i":RX
	for /f %%j in ('type grupos\grupos%%i.txt') do (
		rem Asignamos os grupos de usuarios as carpetas dos grupos
		icacls  %unidade%\Datos\Cursos\%%i\%%j  /grant "G-%%j":RX
	)
)

REM se po�emos 
REM icacls  %unidade%\Datos\Cursos\%%i  /grant G-%%i:(OI)(CI)RX
rem Falla