@echo off
call 00-variables.bat

md %unidade%\Datos

rem Creamos as carpetas para albergar a informaci�n dos Usuarios
md %unidade%\Datos\Usuarios
md %unidade%\Datos\Usuarios\Perf�s
md %unidade%\Datos\Usuarios\Redirecci�ns
md %unidade%\Datos\Usuarios\Alumnos
md %unidade%\Datos\Usuarios\Profesores

rem Creamos o resto de carpetas

md %unidade%\Datos\Cursos
md %unidade%\Datos\Administraci�n
md %unidade%\Datos\Com�n
md %unidade%\Datos\Com�n\Com�nProfes
md %unidade%\Datos\Com�n\Com�nAlumn
