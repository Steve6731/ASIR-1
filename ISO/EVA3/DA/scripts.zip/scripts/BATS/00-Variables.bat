@echo off
REM Informaci�n do Dominio
set nomeDominio=xilgaro
set extDominio=local

REM Directorio ra�z da unidade DATOS
set unidade=D:

REM Cargamos a p�ina de c�digos de idioma correcto para que non de problemas coas tildes
mode con cp select=1250 > nul