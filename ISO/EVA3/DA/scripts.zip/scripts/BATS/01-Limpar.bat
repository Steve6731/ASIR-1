@echo off
rem Cargamos as variables globais
call 00-variables.bat

rem -----------------------------
rem Eliminamos a carpeta Datos
rem -----------------------------

rem Tomamos posesión
takeown /r /f %unidade%\Datos /d s
rem Engadimos na ACL de todos os arquivos/carpetas
rem a ACE Administradores Control Total
icacls %unidade%\Datos /grant administradores:F /T
rem Borramos a carpeta sen que pida confirmación
rd /s /q %unidade%\Datos

rem -----------------------------
rem Eliminamos a OU Usuarios
rem -----------------------------
dsrm  "ou=Usuarios, dc=%nomeDominio%, dc=%extDominio%" -subtree -noprompt
