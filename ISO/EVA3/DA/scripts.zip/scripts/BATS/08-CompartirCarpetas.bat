@echo off
call 00-variables.bat

Rem Compartimos as carpetas para os Perf�s e as Redirecci�ns
Rem O seu nome acaba en $ polo que as compartimos de xeito oculto
net share Perf�s$=%unidade%\Datos\Usuarios\Perf�s /Grant:Todos,Full
net share Redirecci�ns$=%unidade%\Datos\Usuarios\Redirecci�ns /Grant:Todos,Full

Rem Compartimos o resto de carpetas do dominio

net share Alumnos=%unidade%\Datos\Usuarios\Alumnos /Grant:Todos,Full
net share Profesores=%unidade%\Datos\Usuarios\Profesores /Grant:Todos,Full
net share Cursos=%unidade%\Datos\Cursos /Grant:Todos,Full
net share Administraci�n=%unidade%\Datos\Administraci�n /Grant:Todos,Full
net share Com�n=%unidade%\Datos\Com�n /Grant:Todos,Full