﻿#####################################################
# Converte o Listaxe do Grupo (AL047) obtido do xade 
# Nun arquivo .csv cos seus campos separados por :
# 
#
# Emprego: listadoToCsv clase.pdf
#
# Crea  un arquivo .csv que se chama igual 
# que o arquivo pasado como argumento
#
# Neste caso crearía clase.csv
#
# ---------------------------------------------------
#
# Emprega a utilidade pdftotext
# http://www.foolabs.com/xpdf/download.html
#
#####################################################

#cls
#echo $text

 if ($args.Count -ne 1){
    echo "ERROR SINTAXE: listadoToCsv listadoGrupo.pdf"
    #claseUTF2.txt
    #Write-Host "Hola mundo, tu nombre es $($args[0])"
    }
    else  {
          
          if (-not (Test-Path $args[0]))
          { echo "Error $args[0] non existe"
            [Environment]::Exit(1)

          }
          else{
          # Comproband
          #Write-Host "Hola mundo, tu nombre es $($args[0])"
          #write-host "pasaste $($args.count)" 
          
      
          #Convirto o pdf a txt empregando a ferramenta externa pdftotext
          .\pdftotext -layout $args[0] -enc UTF-8 texto.txt

              #Cargo arquivo
          #$text = [string]::Join("`n", (Get-Content -en UTF8 C:\scripts\PDF\claseUTF2.txt))
          $text = [string]::Join("`n", (Get-Content -en UTF8 texto.txt))

          ########################################################################
          #Fago algúns cambios para que me sexa máis sinxelo extraer a información
          ########################################################################
          
          #Cambio o carácter \n por @
          $text=$text -replace "`n",'@'
          $text=$text -replace "@@",'@'

          #Cambio o carácter @ por \n####
          $text = [regex]::Replace($text,"@","`n####   ") 

          #Creo un arquivo temporal, para filtrar nel
          #Non son quen de filtrar directamente na variable
          #$text | Out-File C:\scripts\PDF\00-temp.txt
          $text | Out-File 00-temp.txt

          #Quédome só coas liñas que comezen por 1 ou 2 díxitos
          #$text = Get-Content C:\scripts\PDF\00-temp.txt | Where-Object {$_ -match "^####\s*[0-9][0-9]?\s"} 
          $text = Get-Content 00-temp.txt | Where-Object {$_ -match "^####\s*[0-9][0-9]?\s"} 

          #Eliminamos o que insertamos para que foxe máis sinxelo recoñecer o comezo de liña
          $text=$text -replace "^####\s*",''

          #Reemplazamos o número do alumno por ese mesmo número seguido de :
          $text=$text -ireplace "(^[0-9][0-9]*)",'$1:   '

          # Necesitamos separar os campos con máis de un espacio - Engado espacios despois do segundo campo
          $text=$text -ireplace "(^[0-9][0-9]*:\s*[0-9][0-9][0-9][0-9][0-9]\s)",'$1   '

          # Engado espacios despois da data
          $text=$text -ireplace "([0-9][0-9]/[0-9][0-9]/[0-9][0-9]\s)",'   $1    '

          ########################################################################
          #Comezamos a reemprazar os brancos que separan os campos por :
          ########################################################################

          #Reemprazo dous brancos seguidos por :
          $text=$text -replace "[ ][ ]",': '
          
          #Reemprazo : seguidos de calquera número de blancos por :
          $text=$text -replace ":[ ]*",':'

          #Reemprazo calquera repetición de : por un :
          
          $text=$text -replace ":+",':'

          # Reemprazo os espacios en blanco por @
          #$text=$text -replace "[ ]",'@'

          #Gardo o arquivo como .csv
          $nomeArquivo=[System.IO.Path]::GetFileNameWithoutExtension($args[0])
          $nomeArquivo=$nomeArquivo+".csv"
          write-output $text | out-file -Filepath $nomeArquivo
          
          #######################################################################
          # Limpando
          #######################################################################
          
          #Eliminamos os arquivos temporais  
          Remove-Item texto.txt
          Remove-Item 00-temp.txt
          
        }
  
        }