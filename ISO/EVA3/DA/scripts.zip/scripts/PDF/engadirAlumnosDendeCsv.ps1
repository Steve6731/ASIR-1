﻿#####################################################
# Engade os alumnos ó dominio a partir dun arquivo .csv
# Nun arquivo .csv cos seus campos separados por :
# 
#
# Emprego: engadirAlumnosDendeCsv clase.csv grupo curso
# Exemplo: engadirAlumnosDendeCsv clase.csv 1ESOA 1ESO
# Engade os alumnos coa súa información na correspondente OU
#####################################################

$nomeDominio="xilgaro"
$extDominio="local"

function quitarAcentos($texto)
# Esta función recibe unha cadea de texto 
# Devolve a mesma cadea de texto en minúsculas e sen acentos
# Útil para xerar os nomes de login
{
    $texto=$texto.ToLower()
    $texto=$texto -replace "á",'a'
    $texto=$texto -replace "é",'e'
    $texto=$texto -replace "í",'i'
    $texto=$texto -replace "ó",'o'
    $texto=$texto -replace "ú",'u'
    return $texto
}



function nomeAltaUsuario($username)
# Esta función devolve un nome válido para dar de alta ó usuario
# Antes de dar de alta o usuario, comproba se existe
# Se existe engádelle un índice ata que ese nome de usuario está libre
# Probaría lois, lois2, lois3, ...
# Devolve o nome co que o usuario é dado de alta 


{  
    $usernameOut=$username
    $existe=(dsquery user -samid $username)
    $i=2
    while ($existe -ne $null){
        #echo $username$i
        $usernameOut=$username+$i
        $existe=(dsquery user -samid $username$i)
        $i++
    }

    #Pasamos o nome de login a minúsculas e quitamos acentos

    $usernameOut=quitarAcentos($usernameOut)
	
	return $usernameOut
}

################# PROGRAMA PRINCIPAL ############################


if ($args.Count -ne 3){
    echo "ERROR SINTAXE: engadirAlumnos clase.csv Grupo Curso"
    echo "Exemplo: engadirAlumnos clase.csv 1ESOA 1ESO"
    #claseUTF2.txt
    #Write-Host "Hola mundo, tu nombre es $($args[0])"
    }
    else {

          #Comprobamos que as OU's existen
          $ouPath="ou=$($args[1]),ou=$($args[2]),ou=Alumnos,ou=Usuarios, dc=$($nomeDominio), dc=$($extDominio)"
          $ouExiste=[adsi]::Exists("LDAP://$ouPath")
          
                  
        #  $ouExiste=[adsi]::Exists("LDAP://ou=$($args[2]),ou=Usuarios, dc=$($nomeDominio), dc=$($extDominio)")
          if ($ouExiste -eq $False) {
            echo "ERROR: A Unidade Organizativa $($ouPath) non existe" }

            else {

                   # Comprobamos se existe o grupo

                  #$ouExiste=[adsi]::Exists("LDAP://ou=$($args[1]),ou=$($args[2]),ou=Usuarios, dc=$($nomeDominio), dc=$($extDominio)")

                  $grupoExiste=[adsi]::Exists("LDAP://cn=G-$($args[1]),$ouPath")

                  if ($grupoExiste -eq $False) {
                     echo "ERROR: O grupo G-$($args[1]) non existe en $($ouPath)" }

                     else {

            ################# SE TODO ESTÁ CORRECTO ############################
#			echo Comenzando!

            #.\listadoToCsv $args[0]
            
            #Obtemos o nome do arquivo xerado
            $nomeArquivo=[System.IO.Path]::GetFileNameWithoutExtension($args[0])
            $nomeArquivo=$nomeArquivo+".csv"


            #$text = [string]::Join("`n", (Get-Content $args[0]))
            $text = Get-Content $nomeArquivo
            #echo $text

            ########################################################
            # Recorremos o arquivo, extraendo os campos dos usuarios
            # Para elo recorro a variable
            foreach  ($i in $text) 
            {
                $num=echo $i  | %{$_.split(':')[0]}
                $cod=echo $i  | %{$_.split(':')[1]}
                $nomeCompleto=echo $i  | %{$_.split(':')[2]} 
                $data=echo $i  | %{$_.split(':')[3]} 
                $dir=echo $i  | %{$_.split(':')[4]} 
                $tlf=echo $i  | %{$_.split(':')[5]} 


                #Obtemos por separado Nome e Apelidos
    
                $nomeCompleto=$nomeCompleto -replace ",[ ]",','
                $nome=echo $nomeCompleto  | %{$_.split(',')[1]}
                $apelidos=echo $nomeCompleto  | %{$_.split(',')[0]}
                $apelido1=echo $apelidos  | %{$_.split(' ')[0]}

                #Xeramos o login do usuario
                #O nome de usuario será a 1º letra do nome seguido do apelido
                #Ex Lois Toñete será ltoñete
                $login=$nome.Substring(0,1)+$apelido1
                $loginValido=nomeAltaUsuario($login)
				write-host Engadindo $loginValido

                #Xeramos o nome do usuario para amosar
                $displayName=$apelidos+", "+$nome

                # echo num:$num cod:$cod dat:$data fn:$fn ln:$ln
                #echo $fn
                #dsadd user "cn=$($loginValido),ou=$($args[1]),ou=$($args[2]),ou=Usuarios, dc=$($nomeDominio), dc=$($extDominio)" -ln $apelidos -fn $nome -display $displayName -pwd abc123. -memberof "cn=G-$($args[1]),$ouPath"

               
			    dsadd user "cn=$($loginValido),ou=$($args[1]),ou=$($args[2]),ou=Alumnos,ou=Usuarios, dc=$($nomeDominio), dc=$($extDominio)" `
				-ln $apelidos -fn $nome -display $displayName -pwd abc123.  -profile \\xdc-01\Perfís$\$loginValido `
				-hmdir \\xdc-01\alumnos\$loginValido -hmdrv "Z:" `
			    -memberof "cn=G-$($args[1]),$ouPath"
            }
                #######################################################################
                # Limpando
                #######################################################################
          
                #Eliminamos o arquivo temporal  
                Remove-Item $nomeArquivo
            }
         }
         }