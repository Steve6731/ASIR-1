﻿#####################################################
# Engade os alumnos ó dominio a partir dun arquivo .csv
# Nun arquivo .csv cos seus campos separados por :
# 
#
# Emprego: engadirAlumnosDendePdf clase.csv grupo curso
# Exemplo: engadirAlumnosDendePdf clase.csv 1ESOA 1ESO
# Engade os alumnos coa súa información na correspondente OU
#####################################################

$nomeDominio="xilgaro"
$extDominio="local"

################# PROGRAMA PRINCIPAL ############################

if ($args.Count -ne 3){
	#Comprobamos que o número de parámetros sexa correcto
    echo "ERROR SINTAXE: engadirAlumnosDendePdf clase.pdf Grupo Curso"
    echo "Exemplo: engadirAlumnosDendePdf clase.pdf 1ESOA 1ESO"
    
    }
    else {
			#Convertemos o listado en PDF a CSV
			.\listadoToCsv $args[0]
			#Engadimos os alumnos dende o listado en CSV
			.\engadirAlumnosDendeCsv $args[0] $args[1] $args[2]
         }